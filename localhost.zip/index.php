<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
	<meta charset="utf-8">
	<title>Send Email</title>
</head>
<body>
	
	<header>
  		<h1 id="title">Календарь вакцинации в педиатрии</h1>
            <p id="description"> Адамов Святослав</p>
      </header>
	<form class="" action="send.php" method="post">
		<input type="hidden" name="project_name" value="От вашего педиатра">
        <input type="hidden" name="admin_email" value="adamovsvatoslav05@gmail.com">
        <input type="hidden" name="form_subject" value="Are you booked for vaccination?">


		Email <input type="email" name="email" value="" required> <br>
		<input type="text" name="Name" placeholder="ФИО" required> <br>
		<input type="text" name="age" placeholder="Возраст" required> <br>
		<input type="text" name="house	" placeholder="Где будет вакцинироваться" required>
		
		<h1 id="title">Выберите дату</h1>
		<input type="date" class="input w-input" style="background-image:none;padding-left:0px;"name="date" id="davaToday">

		
                  <label for="RP">
                  <input id="RP" name="injectio=other" type="checkbox" value="b1">RP
            </label>
            <label for="V1">
                  <input id="V1" name="injectio-other" type="checkbox" value="b2">V1
            </label>
<label for="V2">
                  <input id="V2" name="injectio-other" type="checkbox" value="b3">V2
            </label>
		<button type="submit" name="send">Send</button>
	</form>
	<script>document.getElementByld('davaToday').valueAsDate=new Date();</script>


</body>
</html>

